import { U as Trigger } from "./intake-DvrR2ZLQ.js";
import { n as Health, t as SourceKind } from "./kind-CXUKebpw.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/mail.d.ts
declare const SOURCE = "mail";
/**
 * `secret` is the app password the provider issues, not the account password: QQ Mail and Gmail both refuse a normal
 * password to an IMAP client, and both issue a separate one for it.
 */
declare const MailConfigSchema: z.ZodObject<{
  address: z.ZodDefault<z.ZodString>;
  imapHost: z.ZodDefault<z.ZodString>;
  imapPort: z.ZodDefault<z.ZodNumber>;
  imapSecure: z.ZodDefault<z.ZodBoolean>;
  smtpHost: z.ZodDefault<z.ZodString>;
  smtpPort: z.ZodDefault<z.ZodNumber>;
  smtpSecure: z.ZodDefault<z.ZodBoolean>;
  secret: z.ZodDefault<z.ZodString>;
  mailboxes: z.ZodDefault<z.ZodString>;
  window: z.ZodDefault<z.ZodNumber>;
  pollSeconds: z.ZodDefault<z.ZodNumber>;
  failuresBeforeError: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
type MailConfig = z.infer<typeof MailConfigSchema>;
/** Returns an error health once `failures` consecutive polls fail, so one network interruption stays quiet. */
declare function pollFailure(failures: number, threshold: number, error: unknown): Health | undefined;
/** Decodes the RFC 2047 encoded words a mail header uses for a non-ASCII sender or subject. */
declare function decodeHeader(text: string): string;
/** The text a person wrote: the plain part when the message is multipart, otherwise the body itself. */
declare function bodyOf(raw: string): string;
/** Turns a fetched message into a Trigger, or undefined when it carries nothing a person wrote. */
declare function triggerOf(raw: string, config: MailConfig, mailbox: string, seq: number): Trigger | undefined;
declare const mailKind: SourceKind<MailConfig>;
declare const name = "dsh-superagent-mail";
declare const inject: string[];
declare function apply(ctx: Context): void;
//#endregion
export { MailConfig, MailConfigSchema, SOURCE, apply, bodyOf, decodeHeader, inject, mailKind, name, pollFailure, triggerOf };