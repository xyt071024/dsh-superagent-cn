import { U as Trigger } from "./intake-DvrR2ZLQ.js";
import { n as Health, t as SourceKind } from "./kind-CXUKebpw.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/qq.d.ts
declare const SOURCE = "qq";
/** OneBot v11 message, kept loose so a different implementation may add fields without breaking the read. */
declare const MessageSchema: z.ZodObject<{
  message_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
  message_type: z.ZodOptional<z.ZodString>;
  group_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
  user_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
  raw_message: z.ZodOptional<z.ZodString>;
  message: z.ZodOptional<z.ZodUnknown>;
  time: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
  sender: z.ZodOptional<z.ZodObject<{
    user_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
    nickname: z.ZodOptional<z.ZodString>;
    card: z.ZodOptional<z.ZodString>;
  }, z.core.$loose>>;
  post_type: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
type OneBotMessage = z.infer<typeof MessageSchema>;
/**
 * `endpoint` and `token` are installation facts rather than hidden secrets: an operator has to read the value back to
 * correct it, so the token is an ordinary field that is simply never logged.
 */
declare const QqConfigSchema: z.ZodObject<{
  endpoint: z.ZodDefault<z.ZodString>;
  token: z.ZodDefault<z.ZodString>;
  groups: z.ZodDefault<z.ZodString>;
  privateMessages: z.ZodDefault<z.ZodBoolean>;
  observeAll: z.ZodDefault<z.ZodBoolean>;
  pollSeconds: z.ZodDefault<z.ZodNumber>;
  failuresBeforeError: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
type QqConfig = z.infer<typeof QqConfigSchema>;
/** Calls one OneBot action, turning a refused action into an error even though it arrives with HTTP 200. */
declare function call(config: Pick<QqConfig, 'endpoint' | 'token'>, action: string, params?: Record<string, unknown>, signal?: AbortSignal): Promise<unknown>;
/** Flattens OneBot's message segments to plain text, keeping @ targets so an address stays detectable. */
declare function plainText(message: OneBotMessage): string;
/** Whether a group message @s the agent's own account. `all` is @everyone: it reaches the agent but does not name it. */
declare function mentions(message: OneBotMessage, self: string): boolean;
declare const threadOf: (message: OneBotMessage) => string;
/** Turns one OneBot message into a Trigger, or undefined when it is not for the agent. */
declare function triggerOf(message: OneBotMessage, config: QqConfig, self: string): Trigger | undefined;
/** Returns an error health once `failures` consecutive polls fail, so one network interruption stays quiet. */
declare function pollFailure(failures: number, threshold: number, error: unknown): Health | undefined;
declare const qqKind: SourceKind<QqConfig>;
declare const name = "dsh-superagent-qq";
declare const inject: string[];
declare function apply(ctx: Context): void;
//#endregion
export { QqConfig, QqConfigSchema, SOURCE, apply, call, inject, mentions, name, plainText, pollFailure, qqKind, threadOf, triggerOf };