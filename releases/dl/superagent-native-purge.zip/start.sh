#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js not found. Install Node.js 22.19 or newer from https://nodejs.org"; exit 1; }
command -v npm  >/dev/null || { echo "npm not found. Install Node.js 22.19 or newer from https://nodejs.org"; exit 1; }
TARGET="$HOME/.dsh/profiles/superagent"
if [ -f "$TARGET/package.json" ]; then
  echo "A profile named superagent already exists at $TARGET."
  echo "Move it away first, or edit start.sh to use another name, then run this again."
  exit 1
fi
mkdir -p "$TARGET"
cp -R ./profile/. "$TARGET"/
sed -i.bak "s|__STATE_DIR__|$HOME/.dsh/state/superagent|" "$TARGET/cordis.patch.yml" && rm -f "$TARGET/cordis.patch.yml.bak"
( cd "$TARGET" && npm install --no-audit --no-fund --silent )
command -v dsh >/dev/null || { echo "dsh not found. Install DeepSeek Harness: npm i -g @deepseek-ai/dsh"; exit 1; }
exec dsh --profile superagent --no-open
