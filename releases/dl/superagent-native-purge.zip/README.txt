Super Agent — ready-to-run bundle (purge)

1. Install Node.js 22.19 or newer (https://nodejs.org).
2. Install DeepSeek Harness: npm i -g @deepseek-ai/dsh
3. Run start.cmd (Windows) or ./start.sh (macOS, Linux).
   The first run installs this profile into ~/.dsh/profiles/superagent and its one dependency.
4. The launcher prints the address with its own token (the port is chosen on your machine at first run).

The unzip folder can be anywhere: nothing runs from it after the first launch.
To remove everything, delete ~/.dsh/profiles/superagent; nothing else is touched.

PURGE BUILD: this profile also lists dsh-purge-community, which edits the DSH host itself.
Apply the host patch with `dsh purge apply` once, and `dsh purge revert` to undo it. A DSH upgrade can
invalidate the patch until it is re-applied; see purge.md on the documentation site for what it changes.
