import { U as Trigger } from "./intake-CDiVOlO0.js";
import { n as Health, t as SourceKind } from "./kind-D9xgRvi3.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/qq.d.ts
declare const SOURCE = "qq";
/** OneBot v11 message, kept loose so a different implementation may add fields without breaking the read. */
declare const MessageSchema: z.ZodObject<{
  message_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
  message_type: z.ZodOptional<z.ZodString>;
  group_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
  user_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
  raw_message: z.ZodOptional<z.ZodString>;
  message: z.ZodOptional<z.ZodUnknown>;
  time: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
  sender: z.ZodOptional<z.ZodObject<{
    user_id: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodString]>>;
    nickname: z.ZodOptional<z.ZodString>;
    card: z.ZodOptional<z.ZodString>;
  }, z.core.$loose>>;
  post_type: z.ZodOptional<z.ZodString>;
}, z.core.$loose>;
type OneBotMessage = z.infer<typeof MessageSchema>;
/**
 * `endpoint` and `token` are installation facts rather than hidden secrets: an operator has to read the value back to
 * correct it, so the token is an ordinary field that is simply never logged.
 */
declare const QqConfigSchema: z.ZodObject<{
  endpoint: z.ZodDefault<z.ZodString>;
  token: z.ZodDefault<z.ZodString>;
  groups: z.ZodDefault<z.ZodString>;
  privateMessages: z.ZodDefault<z.ZodBoolean>;
  observeAll: z.ZodDefault<z.ZodBoolean>;
  pollSeconds: z.ZodDefault<z.ZodNumber>;
  failuresBeforeError: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
type QqConfig = z.infer<typeof QqConfigSchema>;
/** Calls one OneBot action, turning a refused action into an error even though it arrives with HTTP 200. */
declare function call(config: Pick<QqConfig, 'endpoint' | 'token'>, action: string, params?: Record<string, unknown>, signal?: AbortSignal): Promise<unknown>;
/** Flattens OneBot's message segments to plain text, keeping @ targets so an address stays detectable. */
declare function plainText(message: OneBotMessage): string;
/** Whether a group message @s the agent's own account. `all` is @everyone: it reaches the agent but does not name it. */
declare function mentions(message: OneBotMessage, self: string): boolean;
declare const threadOf: (message: OneBotMessage) => string;
/**
 * Turns one OneBot message into a Trigger, or undefined when it is not for the agent.
 *
 * `source` is the kind that received it: the same OneBot protocol serves QQ, a WeChat bridge and a WeCom bridge, and each
 * must be recorded under its own name so a reply goes back out through the bridge it arrived on.
 */
declare function triggerOf(message: OneBotMessage, config: QqConfig, self: string, source?: string): Trigger | undefined;
/** Returns an error health once `failures` consecutive polls fail, so one network interruption stays quiet. */
declare function pollFailure(failures: number, threshold: number, error: unknown): Health | undefined;
/**
 * Builds the kind for one OneBot implementation.
 *
 * QQ, a WeChat bridge and a WeCom bridge all speak OneBot v11, so they share this code and differ only in the name they
 * record and the labels the operator reads. One kind per platform — rather than one kind with a platform field — is what
 * lets each carry its own Policy list, its own instances and its own health.
 */
declare function oneBotKind(kind: string, title: {
  zh: string;
  en: string;
}, description: {
  zh: string;
  en: string;
}, threadVariable: {
  key: string;
  description: {
    zh: string;
    en: string;
  };
}): SourceKind<QqConfig>;
/** The three platforms this OneBot implementation reaches, each with the name and wording the operator sees. */
declare const ONE_BOT_KINDS: readonly [{
  readonly kind: "qq";
  readonly title: {
    readonly zh: "QQ";
    readonly en: "QQ";
  };
  readonly description: {
    readonly zh: "通过 OneBot 端点接收 QQ 群和私聊消息。群里只有 @ 智能体的消息才算发给它，私聊则都是。";
    readonly en: "Receives QQ group and private messages through a OneBot endpoint. In a group only a message that @s the agent is for it; a private message always is.";
  };
  readonly variable: {
    readonly key: "DSH_SUPERAGENT_QQ_THREAD";
    readonly description: {
      readonly zh: "接下工单的 QQ 会话：群号或私聊的对象";
      readonly en: "The QQ conversation that started the ticket: a group number, or the person in a private chat";
    };
  };
}, {
  readonly kind: "wechat";
  readonly title: {
    readonly zh: "微信";
    readonly en: "WeChat";
  };
  readonly description: {
    readonly zh: "通过微信端的 OneBot 桥接收群聊和私聊。群里只有 @ 智能体的消息才算发给它，私聊则都是。桥接要先在微信端启动。";
    readonly en: "Receives WeChat group and private messages through its OneBot bridge. In a group only a message that @s the agent is for it; a private message always is. The bridge has to be started in the WeChat agent first.";
  };
  readonly variable: {
    readonly key: "DSH_SUPERAGENT_WECHAT_THREAD";
    readonly description: {
      readonly zh: "接下工单的微信会话：群号或私聊的对象";
      readonly en: "The WeChat conversation that started the ticket: a group number, or the person in a private chat";
    };
  };
}, {
  readonly kind: "wecom";
  readonly title: {
    readonly zh: "企业微信";
    readonly en: "WeCom";
  };
  readonly description: {
    readonly zh: "通过企业微信端的 OneBot 桥接收消息。群里只有 @ 智能体的消息才算发给它，私聊则都是。";
    readonly en: "Receives WeCom messages through its OneBot bridge. In a group only a message that @s the agent is for it; a private message always is.";
  };
  readonly variable: {
    readonly key: "DSH_SUPERAGENT_WECOM_THREAD";
    readonly description: {
      readonly zh: "接下工单的企业微信会话";
      readonly en: "The WeCom conversation that started the ticket";
    };
  };
}];
declare const name = "dsh-superagent-qq";
declare const inject: string[];
declare function apply(ctx: Context): void;
//#endregion
export { ONE_BOT_KINDS, QqConfig, QqConfigSchema, SOURCE, apply, call, inject, mentions, name, oneBotKind, plainText, pollFailure, threadOf, triggerOf };