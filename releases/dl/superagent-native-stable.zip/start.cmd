@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js not found. Install Node.js 22.19 or newer from https://nodejs.org & exit /b 1)
where npm >nul 2>nul || (echo npm not found. Install Node.js 22.19 or newer from https://nodejs.org & exit /b 1)
set "TARGET=%USERPROFILE%\.dsh\profiles\superagent"
if exist "%TARGET%\package.json" (
  echo A profile named superagent already exists at "%TARGET%".
  echo Move it away first, or edit start.cmd to use another name, then run this again.
  exit /b 1
)
mkdir "%TARGET%" 2>nul
xcopy /E /I /Y "%~dp0profile\*" "%TARGET%\" >nul
pushd "%TARGET%"
powershell -NoProfile -Command "$f='cordis.patch.yml'; $t=(Get-Content $f -Raw).Replace('__STATE_DIR__', ($env:USERPROFILE -replace '\\','/') + '/.dsh/state/superagent'); $port=0; foreach($p in (Get-Random -Minimum 3082 -Maximum 3183), (Get-Random -Minimum 3082 -Maximum 3183), (Get-Random -Minimum 3082 -Maximum 3183)){ if(-not (Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue)){ $port=$p; break } }; if($port -eq 0){ $port=3082 }; $t.Replace('__PORT__', [string]$port) | Set-Content $f -NoNewline; Write-Host ('  port ' + $port + ' - recorded in cordis.patch.yml')"
call npm install --no-audit --no-fund --silent
popd
where dsh >nul 2>nul
if %errorlevel%==0 (
  dsh --profile superagent --no-open
) else (
  echo dsh was not found on PATH. Install DeepSeek Harness: npm i -g @deepseek-ai/dsh
  exit /b 1
)
