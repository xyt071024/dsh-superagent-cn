#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js not found. Install Node.js 22.19 or newer from https://nodejs.org"; exit 1; }
command -v npm  >/dev/null || { echo "npm not found. Install Node.js 22.19 or newer from https://nodejs.org"; exit 1; }
TARGET="$HOME/.dsh/profiles/superagent"
if [ -f "$TARGET/package.json" ]; then
  echo "A profile named superagent already exists at $TARGET."
  echo "Move it away first, or edit start.sh to use another name, then run this again."
  exit 1
fi
mkdir -p "$TARGET"
cp -R ./profile/. "$TARGET"/
sed -i.bak "s|__STATE_DIR__|$HOME/.dsh/state/superagent|" "$TARGET/cordis.patch.yml" && rm -f "$TARGET/cordis.patch.yml.bak"
chosen=""
for _try in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
  _p=$(( 3082 + (RANDOM % 101) ))
  if command -v lsof >/dev/null; then _busy="$(lsof -nP -iTCP:"$_p" -sTCP:LISTEN 2>/dev/null | tail -n +2 | head -1)";
  elif command -v ss >/dev/null; then _busy="$(ss -lntH "sport = :$_p" 2>/dev/null | head -1)"; else _busy=""; fi
  if [ -z "$_busy" ]; then chosen="$_p"; break; fi
done
[ -n "$chosen" ] || chosen=3082
sed -i.bak "s|__PORT__|$chosen|" "$TARGET/cordis.patch.yml" && rm -f "$TARGET/cordis.patch.yml.bak"
echo "  port $chosen (written to $TARGET/cordis.patch.yml)"
( cd "$TARGET" && npm install --no-audit --no-fund --silent )
command -v dsh >/dev/null || { echo "dsh not found. Install DeepSeek Harness: npm i -g @deepseek-ai/dsh"; exit 1; }
exec dsh --profile superagent --no-open
