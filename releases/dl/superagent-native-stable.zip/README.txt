Super Agent — ready-to-run bundle (stable)

1. Install Node.js 22.19 or newer (https://nodejs.org).
2. Install DeepSeek Harness: npm i -g @deepseek-ai/dsh
3. Run start.cmd (Windows) or ./start.sh (macOS, Linux).
   The first run installs this profile into ~/.dsh/profiles/superagent and its one dependency.
4. The launcher prints the address with its own token (the port is chosen on your machine at first run).

The unzip folder can be anywhere: nothing runs from it after the first launch.
To remove everything, delete ~/.dsh/profiles/superagent; nothing else is touched.
